#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <set>
#include <map>

int main(int argc, char* argv[]){
    
    std::string dataset = argv[1];
    std::string command_list = argv[2];
    // std::string target = argv[3];

    std::ifstream dataFrame(dataset);
    std::string line;

    //Unique country into a set
    std::set<std::string> countries;

    //State/Province = key, confrimed cases = value
    //If no state, then use country
    std::map<std::string, int> confirmed;

    while(std::getline(dataFrame,line)){
        
        std::stringstream ss(line);
        std::string state,country;

        int confirmed_cases;

        std::getline(ss, state, ',');
        std::getline(ss, country, ',');

        ss >> confirmed_cases;

        countries.insert(country);

      if (!state.empty()) {
            // Use state as the key if available
            confirmed[state] = confirmed_cases;
        } else {
            // Use country as the key if no state is available
            confirmed[country] = confirmed_cases;
        }
    }


    std::ifstream commandFile(command_list);
    std::string command;
    std::vector<std::string> results;

    while (commandFile >> command) {
        int result = 0;
        std::string target;

        if (commandFile >> target) {
            if (command == "set") {
                // Check if the target is in the set of countries
                if (countries.count(target)) {
                    result = 1;
                }
            } else if (command == "map") {
                // Lookup the number of confirmed cases in the map
                if (confirmed.count(target) > 0) {
                    result = confirmed[target];
                }
            }

            results.push_back(std::to_string(result));
        }
    }

    // Print the results
    for (int i = 0; i < results.size(); i++) {
        std::cout << results[i] << std::endl;
    }

}